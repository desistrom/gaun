<?php
	define('MAGPIE_INPUT_ENCODING', 'UTF-8');
	define('MAGPIE_OUTPUT_ENCODING', 'UTF-8');
	require_once(__DIR__.'/magpierss/rss_fetch.inc');
?>