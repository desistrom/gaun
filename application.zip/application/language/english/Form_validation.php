<?php
$lang['is_unique_change_email'] = "The %s nganu."