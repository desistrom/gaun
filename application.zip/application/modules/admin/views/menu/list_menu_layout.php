
<?php echo $menu; ?>