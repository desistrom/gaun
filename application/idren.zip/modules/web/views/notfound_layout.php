    <style type="text/css">
        .img-news img{
            width: 100%;
            
        }
        .detail_layanan{
            margin-top: 3em;
            padding: 7em 0;
            background-color: #F2F2F2;
        }
        div.row.content-news{
            background-color: #F2F2F2;
        }
    </style>
    <section class="detail_layanan">
      <div class="container-fluid text-center" >
        <div style="display: inline-block;">
            <img src="<?=base_url();?>assets/images/logo/not_found.png">
        </div>
      </div>
    </section>


